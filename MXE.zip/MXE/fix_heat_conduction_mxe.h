
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#ifdef FIX_CLASS

FixStyle(heat_conduction_mxe,FixHeatConductionMXE)

#else

#ifndef LMP_FIX_HEAT_CONDUCTION_MXE_H
#define LMP_FIX_HEAT_CONDUCTION_MXE_H

#include "fix.h"

namespace LAMMPS_NS {

class FixHeatConductionMXE : public Fix {
 public:
  FixHeatConductionMXE(class LAMMPS *, int, char **);
  ~FixHeatConductionMXE();
  int setmask();
  void init();
  void setup(int);
  void min_setup(int);
  void post_force(int);
  void post_force_respa(int, int, int);
  void min_post_force(int);
  double compute_scalar();
  double compute_vector(int);
  double memory_usage();
  double exp16(double);
  void init_list(int, class NeighList *);
  void unpack_forward_comm(int, int, double*);
  int pack_forward_comm(int, int*, double*, int, int*);
  //int pack_forward_comm(int, int*, double*, int, int*);

 private:
  double xvalue,yvalue,zvalue;
  double Kt, HeatTransportTimeStep, rdcut, Tmax,tau;
  int varflag,iregion, init_ballistic;
  char *xstr,*ystr,*zstr,*estr;
  char *idregion;
  int xvar,yvar,zvar,evar,xstyle,ystyle,zstyle,estyle;
  double foriginal[4],foriginal_all[4];
  int force_flag;
  int nlevels_respa;
  int loop;
  class NeighList *list;

  int maxatom;
  double **sforce;
};

}

#endif
#endif

/* ERROR/WARNING messages:

E: Illegal ... command

Self-explanatory.  Check the input script syntax and compare to the
documentation for the command.  You can use -echo screen as a
command-line option when running LAMMPS to see the offending line.

E: Region ID for fix addforce does not exist

Self-explanatory.

E: Variable name for fix addforce does not exist

Self-explanatory.

E: Variable for fix addforce is invalid style

Self-explanatory.

E: Cannot use variable energy with constant force in fix addforce

This is because for constant force, LAMMPS can compute the change
in energy directly.

E: Must use variable energy with fix addforce

Must define an energy vartiable when applyting a dynamic
force during minimization.

*/
