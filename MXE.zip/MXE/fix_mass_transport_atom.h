
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#ifdef FIX_CLASS

FixStyle(mass_transport/atom,FixMassTransportAtom)

#else

#ifndef LMP_FIX_MASS_TRASNPORT_ATOM_H
#define LMP_FIX_MASS_TRASNPORT_ATOM_H

#include <stdio.h>
#include "fix.h"

namespace LAMMPS_NS {

class FixMassTransportAtom : public Fix {
 public:
  FixMassTransportAtom(class LAMMPS *, int, char **);
  ~FixMassTransportAtom();
  int setmask();
  void init();
  void init_list(int id, NeighList *ptr);
  void setup(int);
  double exponential(double val);
  void initial_integrate(int vflag);
  void pre_force(int vflag);
  int pack_forward_comm(int n, int *list, double *buf,
                                  int pbc_flag, int *pbc);
  void unpack_forward_comm(int n, int first, double *buf);
  int pack_reverse_comm(int n, int first, double *buf);
  void unpack_reverse_comm(int n, int *list, double *buf);
  double compute_scalar();
  double memory_usage();

 private:
  int nmax;
  int diff_flag, atom_flag, rescale_flag;
  double nu, Qm, dt, rdcut, xmin, xmax, difftime;
  class NeighList *list;
  double **dxi_dt;

};

}

#endif
#endif

