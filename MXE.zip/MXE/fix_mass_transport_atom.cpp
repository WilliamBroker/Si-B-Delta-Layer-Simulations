
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <mpi.h>
#include <cstdlib>
#include <cstring>
#include "fix_mass_transport_atom.h"
#include "atom.h"
#include "domain.h"
#include "update.h"
#include "modify.h"
#include "input.h"
#include "variable.h"
#include "memory.h"
#include "error.h"
#include "force.h"
#include "comm.h"
#include "neighbor.h"
#include "neigh_list.h"
#include "neigh_request.h"
#include "pair.h"

#include <iostream>  //std::cout//std::cin

using namespace LAMMPS_NS;
using namespace FixConst;
using namespace std;

/* ---------------------------------------------------------------------- */

FixMassTransportAtom::FixMassTransportAtom(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg), dxi_dt(NULL)
{
  //  fix 1  all mass_transport/atom nu 1.0e8 Qm  0.55  dt  1.0e-5 rcut 2.8  interstitial(o substitutional)  1    xmin  0.01 xmax 1.0   rescale 1/0
  //         [0] [1]         [2]         [3]  [4]  [5]  [6]  [7]  [8]   [9]  [10]     [11]                       [12]  [13]  [14] [15] [16]    [17]  [18]
    
  int index, ntypes;
  char *atom_style = atom->atom_style;
  xmin=0.0001;
  xmax=1.0;
  rescale_flag=0;  
  
  if (strcmp(atom_style,"atomic_mxe_mt") != 0) error->all(FLERR, "Illegal atom_style for diffusion.");
  if (narg < 13 ) error->all(FLERR, "Illegal fix mass_transport/atom command. More inputs are required. See manual");
  if (narg > 19 ) error->all(FLERR, "Illegal fix mass_transport/atom command. Less inputs are required. See manual");
  
  for(index=3; index<narg; index += 2) {  
    
    if (strcmp(arg[index],"nu") == 0) { 
        nu = force->numeric(FLERR,arg[index+1]); 
    } else

    if (strcmp(arg[index],"Qm") == 0) { 
        Qm = force->numeric(FLERR,arg[index+1]); 
    } else

    if (strcmp(arg[index],"dt") == 0) { 
        dt = force->numeric(FLERR,arg[index+1]); 
    } else

    if (strcmp(arg[index],"rdcut") == 0) { 
        rdcut = force->numeric(FLERR,arg[index+1]);
    } else

    if (strcmp(arg[index],"interstitial") == 0) { 
        diff_flag=0; 
        atom_flag = force->inumeric(FLERR,arg[index+1]);
    } else
  
    if (strcmp(arg[index],"substitutional") == 0) {
        diff_flag=1; 
        atom_flag = force->inumeric(FLERR,arg[index+1]);
    } else
    
    if (strcmp(arg[index],"xmin") == 0) {
        xmin = force->numeric(FLERR,arg[index+1]);
    }else
    
    if (strcmp(arg[index],"xmax") == 0) {
        xmax = force->numeric(FLERR,arg[index+1]);
    }else
    
    if (strcmp(arg[index],"rescale") == 0) {
        rescale_flag = force->inumeric(FLERR,arg[index+1]);
    }else{
        error->all(FLERR, "Illegal input for the mass_transport/atom command.");
    }
    
  }

  nmax = 0;
  ntypes = atom->ntypes;
  comm_forward = ntypes; // size from own atoms to ghost atoms
  if (force->newton_pair) comm_reverse = ntypes; //size from ghost atom to own atoms
  
  // scalar output
  scalar_flag = 1;
  
  //reset diffusion time
  difftime=0.0;

}

/* ---------------------------------------------------------------------- */

FixMassTransportAtom::~FixMassTransportAtom()
{
  memory->destroy(dxi_dt); 
}

/* ---------------------------------------------------------------------- */

int FixMassTransportAtom::setmask()
{
  int mask = 0;
  mask |= INITIAL_INTEGRATE;
  mask |= PRE_FORCE;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::init()
{
  if (force->pair == NULL)
    error->all(FLERR,"Fix mass_transport/atom requires a pair style be defined");

  int count = 0;
  for (int i = 0; i < modify->nfix; i++)
    if (strcmp(modify->fix[i]->style,"mass_transport/atom") == 0) count++;
  if (count > 1) error->warning(FLERR,"More than one fix mass_transport/atom");

  // need an occasional full neighbor list

  int irequest = neighbor->request(this,instance_me);
  neighbor->requests[irequest]->pair = 0;
  neighbor->requests[irequest]->fix = 1;
  neighbor->requests[irequest]->half = 1;
  neighbor->requests[irequest]->full = 0;
  neighbor->requests[irequest]->occasional = 0;
  
}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::init_list(int id, NeighList *ptr)
{
  list = ptr;
}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::setup(int vflag)
{
  if (strstr(update->integrate_style,"verlet"))
    pre_force(vflag);
  else
    error->all(FLERR,"Fix mass_transport/atom requires verlet method");
}

/* ---------------------------------------------------------------------- */

double FixMassTransportAtom::exponential(double val)
{ 

  // option 1:
  if( fabs(val)>10.0 ) return exp( 10.0*val/fabs(val) );
  else return exp(val);

  // option 2:
  //double result = exp(val);    
  //if (result>1.0) return 1.0;
  //	  else return result;

  // option 3:
  //double return exp(val);
   
}

void FixMassTransportAtom::initial_integrate(int vflag)
{
  int i,j,ii,jj,inum,jnum,itype,jtype;
  double xtmp,ytmp,ztmp,delx,dely,delz,rsq;
  int *ilist,*jlist,*numneigh,**firstneigh;


  double **x = atom->x;
  double *temp = atom->mxe_temperature;
  double **fxi = atom->fxi;  
  double **xi = atom->xi;
  int *type = atom->type;
  int *mask = atom->mask;
  
  double cutsq = rdcut*rdcut; 
  int nlocal = atom->nlocal;
  //int nghost = atom->nghost;
  int ntypes = atom->ntypes;
  double beta_i, beta_j;  
  double f_ij = 0.0, dmass =0.0;
  double kB = force->boltz; 
  int newton_flag = force->newton_pair;
  double factor=1.0, global_factor=1.0, xi0, xf0, xi1, xf1, val;
  int itipo, jtipo;
  double fi, fj;
  int me;
  
  MPI_Comm_rank(world,&me);
  
  inum = list->inum;
  ilist = list->ilist;
  numneigh = list->numneigh;
  firstneigh = list->firstneigh;
  

  if (ntypes>3 ) error->all(FLERR,"mxe is not implemented for system with more than three atom types");
  
  if (ntypes>2 && diff_flag == 1 ) error->all(FLERR,"Substitutional diffusion is not implemented for system with more than two atom types");
    
  // grow centro array if necessary
  
  if (atom->nmax > nmax) {
    memory->destroy(dxi_dt);
    nmax = atom->nmax;
    memory->create(dxi_dt,nmax,ntypes,"transport/atom:transport");
  }

  // set to zeros the arrays 
  for(i=0; i<nmax; i++)for(j=0; j<ntypes; j++) dxi_dt[i][j]=0.0; 
  
  // comm of dfdxi -> the forces are updated for ghost atoms
  
  comm->forward_comm_fix(this);


  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];

   beta_i = 1.0/(kB * temp[i]);

   if (mask[i] & groupbit) {
        
     xtmp = x[i][0];
     ytmp = x[i][1];
     ztmp = x[i][2];
     itype = type[i];   

     jlist = firstneigh[i];
     jnum = numneigh[i];

     for (jj = 0; jj < jnum; jj++) {
        j = jlist[jj];
        j &= NEIGHMASK;
        jtype = type[j]; 
        
        beta_j = 1.0/(kB * temp[j]);

        //---------------------------------------------------------------------*
        // interstitial diffusion
        
        if (diff_flag == 0 && atom_flag==itype && atom_flag==jtype){ 
            
          delx = xtmp - x[j][0];
          dely = ytmp - x[j][1];
          delz = ztmp - x[j][2];
          rsq = delx*delx + dely*dely + delz*delz;
          if (rsq < cutsq) { 
	        f_ij = (beta_i*fxi[i][atom_flag-1]-beta_j*fxi[j][atom_flag-1])/2.0;
	        dmass= nu*exp(-Qm*beta_j)*(xi[j][atom_flag-1]-xmin)*(xmax-xi[i][atom_flag-1])*exponential(-f_ij) 
                      -nu*exp(-Qm*beta_i)*(xi[i][atom_flag-1]-xmin)*(xmax-xi[j][atom_flag-1])*exponential( f_ij);
                
                if(dmass>=0){
                    if( xi[j][atom_flag-1]<=xmin || xi[i][atom_flag-1]>=xmax ) continue;
                }else{
                    if( xi[j][atom_flag-1]>=xmax || xi[i][atom_flag-1]<=xmin ) continue;
                } 
                
                dxi_dt[i][atom_flag-1] += dmass;
                if(newton_flag || j<nlocal) dxi_dt[j][atom_flag-1] -= dmass;
          }
          
        //---------------------------------------------------------------------*        
        // substitutional diffusion for two type of atoms
        
        }else if (diff_flag == 1 && ntypes<=2 && atom_flag==itype && atom_flag==jtype){ 
            
          delx = xtmp - x[j][0];
          dely = ytmp - x[j][1];
          delz = ztmp - x[j][2];
          rsq = delx*delx + dely*dely + delz*delz;
          if (rsq < cutsq) { 
                f_ij = ( beta_i*(fxi[i][0]-fxi[i][1]) - beta_j*(fxi[j][0]-fxi[j][1]) )/2.0;
	        dmass=  nu*exp(-Qm*beta_j)*(xi[j][0]-xmin)*(xi[i][1]-xmin)*exp(-f_ij) 
                       -nu*exp(-Qm*beta_i)*(xi[i][0]-xmin)*(xi[j][1]-xmin)*exp( f_ij);
                
                if(dmass>=0){
                    if( xi[j][0]<=xmin || xi[i][0]>=xmax || xi[j][1]>=xmax || xi[i][1]<=xmin ) continue;
                }else{
                    if( xi[j][0]>=xmax || xi[i][0]<=xmin || xi[j][1]<=xmin || xi[i][1]>=xmax ) continue;
                }                
                
                dxi_dt[i][0]+= dmass;
                dxi_dt[i][1]-= dmass; 
                if(newton_flag || j<nlocal){
                    dxi_dt[j][0]-= dmass;
                    dxi_dt[j][1]+= dmass; 
                }
          }
          
        }       
        
        //---------------------------------------------------------------------*

      } //end for jj    
    } // end of if
  } //end ii atom
    
  // reverse comm of dx_dt -> from ghost atoms to own atoms
  if (force->newton_pair){
        comm->reverse_comm_fix(this);
  }    

  // calculate the rescaling factor
  
  if(rescale_flag){
  
  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    itype = type[i];

    if (mask[i] & groupbit) {
        
        //---------------------------------------------------------------------*
        // interstitial diffusion
        
        if (diff_flag == 0 && itype == atom_flag && i<nlocal ) {
            
            xi0 = xi[i][atom_flag-1];
            xf0 = xi0 + dxi_dt[i][atom_flag-1]*dt;
            
            if(xf0>xmax && xf0!=xi0){ // x[atom_i]!=xi to avoid nan number
                val = (xmax-xi0)/(xf0-xi0);
                if(factor > val ){factor = val;}            
            }else
                
            if(xf0<xmin && xf0!=xi0){ // x[atom_i]!=xi to avoid nan number
                val = (xmin-xi0)/(xf0-xi0);
                if(factor > val){factor = val;}     
            }                
        
        //---------------------------------------------------------------------*        
        // substitutional diffusion for two type of atoms
        
        }else if (diff_flag == 1 && itype == atom_flag && ntypes<=2 && i<nlocal ) {  
            
            xi0 = xi[i][0];
            xf0 = xi0 + dxi_dt[i][0]*dt;
            
            xi1 = xi[i][1];
            xf1 = xi1 + dxi_dt[i][1]*dt;
            
            // for atom type 0
            if(xf0>xmax && xf0!=xi0){ // x[atom_i]!=xi to avoid nan number
                val = (xmax-xi0)/(xf0-xi0);
                if(factor > val ){factor = val;}            
            }else
        
            if(xf0<xmin && xf0!=xi0){ // x[atom_i]!=xi to avoid nan number
                val = (xmin-xi0)/(xf0-xi0);
                if(factor > val){factor = val;}     
            }
            
            // for atom type 1
            if(xf1>xmax && xf1!=xi1){ // x[atom_i]!=xi to avoid nan number
                val = (xmax-xi1)/(xf1-xi1);
                if(factor > val ){factor = val;}            
            }else
        
            if(xf1<xmin && xf1!=xi1){ // x[atom_i]!=xi to avoid nan number
                val = (xmin-xi1)/(xf1-xi1);
                if(factor > val){factor = val;}     
            }            
            
        }
                     
        //---------------------------------------------------------------------*
            
    } // end of if
  } //end ii atom
  
  // reduce the rescaling factor
  
  MPI_Allreduce(&factor, &global_factor, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
  
  }//end of rescale_flag
  
  // store the final atomic molar fraction
  
  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    itype = type[i];

    if (mask[i] & groupbit) {
        
        //---------------------------------------------------------------------* 
        // interstitial diffusion
        
        if (diff_flag == 0  && itype == atom_flag  && i<nlocal) {
            
            xi[i][atom_flag-1] += dxi_dt[i][atom_flag-1]*dt*global_factor;
            
            if (rescale_flag){ //rescale option is on                
                if( xi[i][atom_flag-1]>xmax )      xi[i][atom_flag-1] = xmax;
                else if( xi[i][atom_flag-1]<xmin ) xi[i][atom_flag-1] = xmin;           
            }else if( xi[i][atom_flag-1]>xmax+1.0e-8 || xi[i][atom_flag-1]< max(0.0,xmin-1.0e-8) ) //rescale option is off
                error->one(FLERR,"Reduce the diffusion time step");
            
        
        
        //---------------------------------------------------------------------*        
        // substitutional diffusion for two type of atoms
        
        }else if (diff_flag == 1  && itype == atom_flag && ntypes<=2  && i<nlocal ) { 
            
            xi[i][0] += dxi_dt[i][0]*dt*global_factor;
            xi[i][1]  = 1.0-xi[i][0];
            
            if (rescale_flag){ //rescale option is on
                
                // for atom type 0
                if( xi[i][0]>xmax )     {xi[i][0]=xmax; xi[i][1]=1.0-xi[i][0];}
                else if( xi[i][0]<xmin ){xi[i][0]=xmin; xi[i][1]=1.0-xi[i][0];}
                
                // for atom type 1
                if( xi[i][1]>xmax )     {xi[i][1]=xmax; xi[i][0]=1.0-xi[i][1];}
                else if( xi[i][1]<xmin ){xi[i][1]=xmin; xi[i][0]=1.0-xi[i][1];}
                
            }else if( xi[i][0]>xmax+1.0e-8 || xi[i][0]< max(0.0,xmin-1.0e-8) || 
                      xi[i][1]>xmax+1.0e-8 || xi[i][1]< max(0.0,xmin-1.0e-8) ) //rescale option is off
                error->one(FLERR,"Reduce the diffusion time step");
            
        }       
        
        //---------------------------------------------------------------------*
            
    } // end of if
    
  } //end ii atom
  
  //update the diffusion time
  difftime += dt*global_factor;

}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::pre_force(int vflag)
{

  double **fxi = atom->fxi;
  double **xi = atom->xi;
  double *temp = atom->mxe_temperature;
  int nlocal = atom->nlocal;
  int *mask = atom->mask;
  
  int *type = atom->type, itype;
  int ntypes = atom->ntypes;
  
  double ibi, dxlo, dxhi;

  // adjustment for the min value of the atomic molar fraction  
  for (int i = 0; i < nlocal; i++) {
    if (mask[i] & groupbit) {
  
        itype = type[i];
        ibi  = force->boltz*temp[i]; // (ev/K * K) = eV
        
        if (diff_flag == 0 ){
            
          dxlo = xi[i][itype-1]-xmin+1.0e-4;     //if(dxlo<1.0e-4) dxlo=1.0e-4;
          dxhi = xmax-xi[i][itype-1]+1.0e-4;     //if(dxhi<1.0e-4) dxhi=1.0e-4;
            
          fxi[i][itype-1] += log(dxlo/dxhi)*ibi;     
        
        } else if (diff_flag == 1 ){
            
          for(itype=1; itype<=ntypes; itype++){
              
            dxlo = xi[i][itype-1]-xmin+1.0e-4; //if(dxlo<1.0e-4) dxlo=1.0e-4;
          
            fxi[i][itype-1] += log(dxlo)*ibi;
          }
        }
        
    }
  }
  
}

/* ---------------------------------------------------------------------- */

int FixMassTransportAtom::pack_forward_comm(int n, int *list, double *buf,
                                  int pbc_flag, int *pbc)
{
  int i,j,m,type,ntypes;

  ntypes = atom->ntypes;
  m=0;  
  for(i = 0; i < n; i++){
    j = list[i];
    for(type=0;type<ntypes;type++)buf[m++]=atom->fxi[j][type];
  }
  
  return m;  
}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::unpack_forward_comm(int n, int first, double *buf)
{
  int i,m,last,type,ntypes;
  
  ntypes = atom->ntypes;
  m=0;
  last = first+n;
  for(i = first; i < last; i++){
    for(type=0;type<ntypes;type++)atom->fxi[i][type] = buf[m++];
  }

}

/* ---------------------------------------------------------------------- */

int FixMassTransportAtom::pack_reverse_comm(int n, int first, double *buf)
{    
  int i,m,last, type, ntypes;

  ntypes = atom->ntypes;
  m = 0;
  last = first + n;
  for (i = first; i < last; i++){
      for(type=0;type<ntypes;type++)buf[m++] = dxi_dt[i][type];
  }

  return m;
  
}

/* ---------------------------------------------------------------------- */

void FixMassTransportAtom::unpack_reverse_comm(int n, int *list, double *buf)
{
  int i,j,m, type, ntypes;
  
  ntypes = atom->ntypes;
  m = 0;
  for (i = 0; i < n; i++) {
    j = list[i];
    for(type=0;type<ntypes;type++)dxi_dt[j][type] += buf[m++];
  }

}

double FixMassTransportAtom::compute_scalar()
{
  return difftime;
}

/* ----------------------------------------------------------------------
   memory usage of local atom-based array
------------------------------------------------------------------------- */

double FixMassTransportAtom::memory_usage()
{
  double bytes;
  int ntypes = atom->ntypes;
  bytes = atom->nmax*ntypes*sizeof(double);
  return bytes;
}
