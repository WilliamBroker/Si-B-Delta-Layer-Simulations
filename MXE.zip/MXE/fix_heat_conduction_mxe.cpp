
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <string.h>
#include <stdlib.h>
#include "fix_heat_conduction_mxe.h"
#include "atom.h"
#include "atom_masks.h"
#include "accelerator_kokkos.h"
#include "update.h"
#include "modify.h"
#include "neigh_request.h"
#include "neigh_list.h"
#include "domain.h"
#include "region.h"
#include "respa.h"
#include "input.h"
#include "variable.h"
#include "memory.h"
#include "error.h"
#include "force.h"

using namespace LAMMPS_NS;
using namespace FixConst;

enum{NONE,CONSTANT,EQUAL,ATOM};

/* ---------------------------------------------------------------------- */
/*Originally taken from fix addforce*/
FixHeatConductionMXE::FixHeatConductionMXE(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg)
{

  // fix 1 all heat_conduction_mxe Kt 100.0 dt 0.1 Tmax 600 loop 1 rdcut 2.8 tau 0.05 (if value is 0.0 then pure diffusive regime is used)
  if (narg != 15) error->all(FLERR,"Illegal fix heat_conduction_mxe command");

  if (strcmp(arg[3],"Kt") == 0) Kt = force->numeric(FLERR,arg[4]);

  if (strcmp(arg[5],"dt") == 0) HeatTransportTimeStep = force->numeric(FLERR,arg[6]);

  if (strcmp(arg[7],"Tmax") == 0) Tmax = force->numeric(FLERR,arg[8]);

  if (strcmp(arg[9],"loop") == 0) loop = force->numeric(FLERR,arg[10]);

  if (strcmp(arg[11],"rdcut") == 0) rdcut = force->numeric(FLERR,arg[12]);

  if (strcmp(arg[13],"tau") == 0) tau = force->numeric(FLERR,arg[14]);

  if (narg != 15) error->all(FLERR,"Illegal fix ttemp command");

  comm_forward = 1;

  init_ballistic = 0;

  dynamic_group_allow = 1;
  scalar_flag = 1;
  vector_flag = 1;
  size_vector = 3;
  global_freq = 1;
  extscalar = 1;
  extvector = 1;

  xstr = ystr = zstr = NULL;

  xvalue = 0.0;
  xstyle = CONSTANT;

  yvalue = 0.0;
  ystyle = CONSTANT;

  zvalue = 0.0;
  zstyle = CONSTANT;

  // optional args

  nevery = 1;
  iregion = -1;
  idregion = NULL;
  estr = NULL;

  force_flag = 0;
  foriginal[0] = foriginal[1] = foriginal[2] = foriginal[3] = 0.0;

  maxatom = 1;
  memory->create(sforce,maxatom,4,"addforce:sforce");
}

/* ---------------------------------------------------------------------- */

FixHeatConductionMXE::~FixHeatConductionMXE()
{
  delete [] xstr;
  delete [] ystr;
  delete [] zstr;
  delete [] estr;
  delete [] idregion;
  memory->destroy(sforce);
}

/* ---------------------------------------------------------------------- */

int FixHeatConductionMXE::setmask()
{
  datamask_read = datamask_modify = 0;

  int mask = 0;
  mask |= POST_FORCE;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::init()
{

  // need a full neighbor list, built whenever re-neighboring occurs

  int irequest = neighbor->request(this,instance_me);
  neighbor->requests[irequest]->pair = 0;
  neighbor->requests[irequest]->fix = 1;
  neighbor->requests[irequest]->half = 0;
  neighbor->requests[irequest]->full = 1;

  estyle = NONE;

  if (xstyle == ATOM || ystyle == ATOM || zstyle == ATOM)
    varflag = ATOM;
  else if (xstyle == EQUAL || ystyle == EQUAL || zstyle == EQUAL)
    varflag = EQUAL;
  else varflag = CONSTANT;

  if (varflag == CONSTANT && estyle != NONE)
    error->all(FLERR,"Cannot use variable energy with "
               "constant force in fix addforce");
  if ((varflag == EQUAL || varflag == ATOM) &&
      update->whichflag == 2 && estyle == NONE)
    error->all(FLERR,"Must use variable energy with fix addforce");

  if (strstr(update->integrate_style,"respa"))
    nlevels_respa = ((Respa *) update->integrate)->nlevels;
}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::setup(int vflag)
{
  if (strstr(update->integrate_style,"verlet"))
    post_force(vflag);
  else {
    ((Respa *) update->integrate)->copy_flevel_f(nlevels_respa-1);
    post_force_respa(vflag,nlevels_respa-1,0);
    ((Respa *) update->integrate)->copy_f_flevel(nlevels_respa-1);
  }
}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::min_setup(int vflag)
{
  post_force(vflag);
}

void FixHeatConductionMXE::init_list(int id, NeighList *ptr)
{
  list = ptr;
}

/* ---------------------------------------------------------------------- */


// Function call for exponential calculation


double FixHeatConductionMXE::exp16(double exp_temp)
{
	
	exp_temp = 1.0 + exp_temp / 16.0;
	exp_temp *= exp_temp; exp_temp *= exp_temp; 
	exp_temp *= exp_temp; exp_temp *= exp_temp;
	
	return exp_temp;	
	
}

/* ---------------------------------------------------------------------- */


void FixHeatConductionMXE::post_force(int vflag)
{
  double **x = atom->x;
  double **f = atom->f;
  double mvv2e = force->mvv2e;
  double **v = atom->v;
  double *temp = atom->mxe_temperature; //Needed for max-ent
  double *mass = atom->mass; //Needed for max-ent
  int *type = atom->type;
  int *mask = atom->mask;
  int newton_flag = force->newton_pair;
  imageint *image = atom->image;
  int nlocal = atom->nlocal;
  bigint natoms = atom->natoms;

  int i,j,ii,jj,inum, jnum, iloop, itype;
  double dx,dy,dz,rsq; 
  double ken, Ke=0.0, xi, temp_latt; 
  double kB = force->boltz; 

  double exp_temp1, exp_temp2;

  double dTi_dt[nlocal];

  double dt = HeatTransportTimeStep;
  double dt_2 = dt*dt;
  double new_temp_i =0.0;

  // set to zeros the arrays 
  for(i=0; i<nlocal; i++) dTi_dt[i]=0.0;

  int *ilist, *jlist,*numneigh,**firstneigh; 

  inum = list->inum;
  ilist = list->ilist;
  numneigh = list->numneigh;
  firstneigh = list->firstneigh;

  if (update->ntimestep % nevery) return;
#if 0
  // If the ballistic flag is used then store
  // previous values of the temperature.
  if (init_ballistic == 0) {
    for (ii = 0; ii < inum; ii++) {
      i = ilist[ii];
      if (mask[i] & groupbit) {
	atom->entropy[i] = temp[i];
      }
    }
    init_ballistic == 1;
  }

  printf("flag %d \n", init_ballistic);
#endif
  //Compute electronic heat conduction
  for (iloop = 0; iloop < loop; iloop++) {

  comm->forward_comm_fix(this);

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    jlist = firstneigh[i];
    jnum = numneigh[i];

    dTi_dt[i] = 0.0;

    if (mask[i] & groupbit) {

	    for (jj = 0; jj < jnum; jj++) {
	      j = jlist[jj];
	      j &= NEIGHMASK;

	      dx = x[i][0] - x[j][0];
	      dy = x[i][1] - x[j][1];
	      dz = x[i][2] - x[j][2];
	      rsq = dx*dx + dy*dy + dz*dz;

	      if (rsq < rdcut*rdcut) {
	      	double theta = -(temp[j] - temp[i])/(Tmax); 
		
	      	dTi_dt[i] += Kt*( temp[j]/Tmax*(1.0-temp[i]/Tmax)*exp16( theta) 
				- temp[i]/Tmax*(1.0-temp[j]/Tmax)*exp16(-theta) );

	      }
     } //end jj
    }
  }//end ii

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];

    if (mask[i] & groupbit) {

	if (tau != 0.0 ) {
	       new_temp_i = temp[i]*(2*tau+dt)/(dt+tau) - atom->entropy[i]*(tau/(tau+dt)) + (Tmax*dTi_dt[i]*dt_2/(dt+tau));
	       atom->entropy[i] = temp[i];
	       temp[i] = new_temp_i;
	}
	else temp[i] += (Tmax*dTi_dt[i]*HeatTransportTimeStep);
    }
  }
 }

}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::post_force_respa(int vflag, int ilevel, int iloop)
{
  if (ilevel == nlevels_respa-1) post_force(vflag);
}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::min_post_force(int vflag)
{
  post_force(vflag);
}

/* ----------------------------------------------------------------------
   potential energy of added force
------------------------------------------------------------------------- */

double FixHeatConductionMXE::compute_scalar()
{
  // only sum across procs one time

  if (force_flag == 0) {
    MPI_Allreduce(foriginal,foriginal_all,4,MPI_DOUBLE,MPI_SUM,world);
    force_flag = 1;
  }
  return foriginal_all[0];
}

/* ----------------------------------------------------------------------
   return components of total force on fix group before force was changed
------------------------------------------------------------------------- */

double FixHeatConductionMXE::compute_vector(int n)
{
  // only sum across procs one time

  if (force_flag == 0) {
    MPI_Allreduce(foriginal,foriginal_all,4,MPI_DOUBLE,MPI_SUM,world);
    force_flag = 1;
  }
  return foriginal_all[n+1];
}

/* ----------------------------------------------------------------------
   memory usage of local atom-based array
------------------------------------------------------------------------- */

double FixHeatConductionMXE::memory_usage()
{
  double bytes = 0.0;
  if (varflag == ATOM) bytes = maxatom*4 * sizeof(double);
  return bytes;
}

/* ---------------------------------------------------------------------- */

int FixHeatConductionMXE::pack_forward_comm(int n, int *list, double *buf,
                                  int pbc_flag, int *pbc)
{
  int m;
    for(m = 0; m < n; m++) buf[m] = atom->mxe_temperature[list[m]];

  return n;
}

/* ---------------------------------------------------------------------- */

void FixHeatConductionMXE::unpack_forward_comm(int n, int first, double *buf)
{
  int i, m;

    for(m = 0, i = first; m < n; m++, i++) atom->mxe_temperature[i] = buf[m];

}

/* ---------------------------------------------------------------------- */

