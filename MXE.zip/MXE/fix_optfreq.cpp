
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <cstring>
#include <cstdlib>
#include "fix_optfreq.h"
#include "atom.h"
#include "update.h"
#include "modify.h"
#include "domain.h"
#include "comm.h"
#include "region.h"
#include "respa.h"
#include "input.h"
#include "variable.h"
#include "memory.h"
#include "error.h"
#include "force.h"

using namespace LAMMPS_NS;
using namespace FixConst;

/* ---------------------------------------------------------------------- */

FixOptFreq::FixOptFreq(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg)
{
  
  // fix fix_id group_id optfreq xvalue yvalue zvalue wmin value
  //       [0]     [1]    [2]     [3]     [4]    [5]  [6]   [7]
  if (narg < 6 || narg > 8) error->all(FLERR,"Illegal fix optfreq command");
  if (narg > 6 && narg < 8) error->all(FLERR,"Illegal fix optfreq command");

  dynamic_group_allow = 1;
  wmin = 1.0; // default value for wmin

  xvalue = force->numeric(FLERR,arg[3]);
  yvalue = force->numeric(FLERR,arg[4]);
  zvalue = force->numeric(FLERR,arg[5]);
  if(narg>6) wmin = force->numeric(FLERR,arg[7]);
  
}

/* ---------------------------------------------------------------------- */

FixOptFreq::~FixOptFreq()
{

}

/* ---------------------------------------------------------------------- */

int FixOptFreq::setmask()
{
  int mask = 0;
  mask |= INITIAL_INTEGRATE;
  mask |= POST_FORCE;
  mask |= MIN_POST_FORCE;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixOptFreq::init()
{
    // Some checks
    
    if (force->pair == NULL)
        error->all(FLERR,"Fix optfreq requires a pair style be defined");
    
    int count = 0;
    for (int i = 0; i < modify->nfix; i++) {
      if (strcmp(modify->fix[i]->style,"optfreq") == 0) count++;
      if (count > 1 && comm->me == 0)
         error->warning(FLERR,"More than one fix optfreq");
    }

}

/* ---------------------------------------------------------------------- */

void FixOptFreq::setup(int vflag)
{
  if (strstr(update->integrate_style,"verlet"))
    post_force(vflag);
}

/* ---------------------------------------------------------------------- */

void FixOptFreq::initial_integrate(int vflag)
{

  double *freq_force = atom->freq_force;
  double *frequency = atom->frequency;
  double *mxe_temperature = atom->mxe_temperature;
  int *mask = atom->mask;
  int nlocal = atom->nlocal;
  double ptime = xvalue; //pseudo-time for dynamic relaxation
  double pdamping = yvalue; //pseudo-damping for dynamic relaxation
  double dfreq = 0.0; // Change in frequency
  
  double value;

  for (int i = 0; i < nlocal; i++) {
    if (mask[i] & groupbit) {

      if (zvalue == 0.0){
        value = ptime*(-0.50*ptime*freq_force[i] - pdamping*ptime*freq_force[i]);
        if ( value>10.0 ) value = 10.0; else if ( value<-10.0 ) value = -10.0; 
        frequency[i] += value;
        if ( frequency[i] < wmin ) frequency[i] = wmin;
      }else {
	//Save original freq and temperature
	dfreq = ptime*(-0.50*ptime*freq_force[i] - pdamping*ptime*freq_force[i]);
	mxe_temperature[i] *= (1.0 + dfreq / frequency[i]);
	frequency[i] += dfreq;
      }
      
    }
  }
  
}


/* ---------------------------------------------------------------------- */

void FixOptFreq::post_force(int vflag)
{

  double *freq_force = atom->freq_force;
  double *frequency = atom->frequency;
  double *temp = atom->mxe_temperature;
  int nlocal = atom->nlocal;
  int *mask = atom->mask;

  double v[6];
  v[0]=v[1]=v[2]=v[3]=v[4]=v[5]=0.0;

  for (int i = 0; i < nlocal; i++) {
    if (mask[i] & groupbit) {
	
      freq_force[i] += 3.0*force->boltz; // this term corresponds to the derivative of log(h*b_i*w_i) with respect to w_i in the free energy functional. The resultanting term is multiplied by b_i*k_b*w_i.
      // V({q}) = Vpot({q}) + \sum_i (1/2)*m_i*wmin^2*|q_i-\bar{q}_i|^2
      // the term |q_i-\bar{q}_i|^2 is only function of w_i, i.e., this term vanishes with the derivative w.r.t. {q}
      // q_i - \bar{q}_i = \bar{x}_i*2^(1/2)/(\beta_i*m_i*w_i^2)^(1/2)
      // d<V>/dw = d<Vpot>/dw - wmin^2*kB*T/(2*wi^3)
      freq_force[i] -= 1.5*force->boltz*wmin*wmin/(frequency[i]*frequency[i]); // to avoid that frequencies become negative values. wmin has to be as smaller as possible.

      // the corresponding contribution of m*v v to the virial stresses 
      v[0]=v[1]=v[2]=force->boltz*temp[i];
      v_tally(i,v);
      
    }
  }
  
}

/* ---------------------------------------------------------------------- */

void FixOptFreq::min_post_force(int vflag)
{

  post_force(vflag);
  initial_integrate(vflag);
}

/* ----------------------------------------------------------------------
   memory usage of local atom-based array
------------------------------------------------------------------------- */

double FixOptFreq::memory_usage()
{
  double bytes = 0.0;
  return bytes;
}
