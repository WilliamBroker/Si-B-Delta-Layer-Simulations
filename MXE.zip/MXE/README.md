**# README #**

To compile and run LAMMPS-MaxEnt you will need to download the lammps distribution (**Tested with lammps-16Aug2018**). Once you download and uncompress LAMMPS, create a folder in src/ named USER-MAXENT, download all files in this distribution into the src directory of LAMMPS. Replace the Makefile in src for the one in USER-MAXENT/Makefile.

**make serial mode=lib yes-user-maxent
or
make yes-user-maxent
make mpi
or 
make mac**

This will generate an executable file,i.e., lmp_mpi, and/or a library that you can link to your code (like IRIS). The files USER-MAXENT/examples provide examples of the parameters that you need to define to run the code. In particular, there are two types of atomic vectors, regular max-ent called '**atomic_mxe**', and mass-transport max-ent called '**atomic_mxe_mt**'. Then the script files are more and less the same for both type of vectors. All examples are self-contained, and ready to use. Output files are automatically generated, so is recommendable to run the in.* files in a separate folder. All potentials files are included. 


### What is this repository for? ###

*** MaxEnt Implementation in LAMMPS
* Version 1.0 (beta)
* Features:
* Thermalized potentials 
* Mass Transport 
* LJ, Tersoff, SW, EAM, EAM-FS, EAM-Alloy, 
* REBO potentials available (More comming soon).
* Custom outputs and commands, etc. **

### How do I get set up? ###

* Summary of set up: 
* make yes-user-maxent
* make mpi
* Configuration: none
* Dependencies: none
* Database configuration: none
* How to run tests: **mpirun -np 4 lmp_mpi -in in.***
* Deployment instructions: ?

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* **mponga@mech.ubc.ca**
* **jmendezg@caltech.edu**