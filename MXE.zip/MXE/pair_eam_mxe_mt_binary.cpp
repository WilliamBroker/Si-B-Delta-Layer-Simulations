/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
   Contributing authors: Stephen Foiles (SNL), Murray Daw (SNL)
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "pair_eam_mxe_mt_binary.h"
#include "atom.h"
#include "force.h"
#include "comm.h"
#include "neighbor.h"
#include "neigh_list.h"
#include "memory.h"
#include "error.h"

using namespace LAMMPS_NS;

#define MAXLINE 1024

/* ---------------------------------------------------------------------- */

PairEAMMXEMT_BI::PairEAMMXEMT_BI(LAMMPS *lmp) : Pair(lmp)
{
  restartinfo = 0;
  manybody_flag = 1;

  nmax = 0;
  rho = NULL;
  rho_mxe = NULL;
  fp = NULL;
  map = NULL;
  type2frho = NULL;

  nfuncfl = 0;
  funcfl = NULL;

  setfl = NULL;
  fs = NULL;

  frho = NULL;
  rhor = NULL;
  z2r = NULL;
  scale = NULL;

  frho_spline = NULL;
  rhor_spline = NULL;
  z2r_spline = NULL;

  // set comm size needed by this Pair

  comm_forward = atom->ntypes; // from own atoms to ghost atoms
  comm_reverse = 1; // from ghost atoms to own atoms
}

/* ----------------------------------------------------------------------
   check if allocated, since class can be destructed when incomplete
------------------------------------------------------------------------- */

PairEAMMXEMT_BI::~PairEAMMXEMT_BI()
{
  if (copymode) return;

  memory->destroy(rho);
  memory->destroy(rho_mxe);
  memory->destroy(fp);

  if (allocated) {
    memory->destroy(setflag);
    memory->destroy(cutsq);
    delete [] map;
    delete [] type2frho;
    map = NULL;
    type2frho = NULL;
    memory->destroy(type2rhor);
    memory->destroy(type2z2r);
    memory->destroy(scale);
  }

  if (funcfl) {
    for (int i = 0; i < nfuncfl; i++) {
      delete [] funcfl[i].file;
      memory->destroy(funcfl[i].frho);
      memory->destroy(funcfl[i].rhor);
      memory->destroy(funcfl[i].zr);
    }
    memory->sfree(funcfl);
    funcfl = NULL;
  }

  if (setfl) {
    for (int i = 0; i < setfl->nelements; i++) delete [] setfl->elements[i];
    delete [] setfl->elements;
    delete [] setfl->mass;
    memory->destroy(setfl->frho);
    memory->destroy(setfl->rhor);
    memory->destroy(setfl->z2r);
    delete setfl;
    setfl = NULL;
  }

  if (fs) {
    for (int i = 0; i < fs->nelements; i++) delete [] fs->elements[i];
    delete [] fs->elements;
    delete [] fs->mass;
    memory->destroy(fs->frho);
    memory->destroy(fs->rhor);
    memory->destroy(fs->z2r);
    delete fs;
    fs = NULL;
  }

  memory->destroy(frho);
  memory->destroy(rhor);
  memory->destroy(z2r);

  memory->destroy(frho_spline);
  memory->destroy(rhor_spline);
  memory->destroy(z2r_spline);
}

/* ---------------------------------------------------------------------- */

void PairEAMMXEMT_BI::compute(int eflag, int vflag)
{
  int i,j,ii,jj,m,inum,jnum,itype,jtype, it_type;
  double xtmp,ytmp,ztmp,delx,dely,delz,evdwl,fpair;
  double rsq,r,p,rhoi,rhoj,rhoip,rhojp,z2,z2p,recip,phip,psip,phi;
  double *coeff;
  int *ilist,*jlist,*numneigh,**firstneigh;

  evdwl = 0.0;
  if (eflag || vflag) ev_setup(eflag,vflag);
  else evflag = vflag_fdotr = eflag_global = eflag_atom = 0;
  
  double **x = atom->x;
  double **f = atom->f;
  int *type = atom->type;
  int nlocal = atom->nlocal;
  int nall = nlocal + atom->nghost;
  int newton_pair = force->newton_pair;

  inum = list->inum;
  ilist = list->ilist;
  numneigh = list->numneigh;
  firstneigh = list->firstneigh;
  
  double *frequency = atom->frequency;
  double *temp = atom->mxe_temperature;
  double *freq_force = atom->freq_force;
  double *mass = atom->mass;
  double **xi = atom->xi;
  double **fxi = atom->fxi;
  int ntypes = atom->ntypes;  
  
  // grow energy and fp arrays if necessary
  // need to be atom->nmax in length

  if (atom->nmax > nmax) {
    memory->destroy(rho);
    memory->destroy(rho_mxe);
    memory->destroy(fp);
    nmax = atom->nmax;
    memory->create(rho,nmax,"pair:rho");
    memory->create(rho_mxe,nmax,"pair:rho");
    memory->create(fp,nmax*ntypes,"pair:fp");
  }

  // kconv = unit conversion to compute the standar deviation of the spectral cloud of atoms
  // sigma = sqrt(2*boltz*temp/mass)/frequency =sqrt(2*boltz*temp/mass/frequency^2)
  // [distance]^2 = ([energy]/[temp])*[temp]*[time]^2/[mass] = ([force]*[time]/[mass]) * ([time]*[distance]) = ftm2v * [distance] = [distance]^2
  // kconv = sqrt(2*boltz*ftm2v)
  // for metal units -> kconv = 1.289531236951867
  double boltz = force->boltz;
  double kconv = sqrt(2*boltz*force->ftm2v);
  double sigma_i = 0.0, sigma_j = 0.0;
  double itemp_i = 0.0, itemp_j = 0.0;
  double inv_imass = 0.0, inv_jmass = 0.0;
  
  double dxi, dyi, dzi, dhi_dwi;
  double dxj, dyj, dzj, dhj_dwj;
  
  int i_quad;
  
  // zero out density

  if (newton_pair) {
    for (i = 0; i < nall; i++) {rho[i] = 0.0; rho_mxe[i] = 0.0;}
  } else for (i = 0; i < nlocal; i++) {rho[i] = 0.0; rho_mxe[i] = 0.0;}

  // rho = density at each atom
  // loop over neighbors of my atoms

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    //itype = type[i];
    jlist = firstneigh[i];
    jnum = numneigh[i];

    for (jj = 0; jj < jnum; jj++) {
      j = jlist[jj];
      j &= NEIGHMASK;

      delx = xtmp - x[j][0];
      dely = ytmp - x[j][1];
      delz = ztmp - x[j][2];
      rsq = delx*delx + dely*dely + delz*delz;

      if (rsq < cutforcesq) {
        //jtype = type[j];
        p = sqrt(rsq)*rdr + 1.0;
        m = static_cast<int> (p);
        m = MIN(m,nr-1);
        p -= m;
        p = MIN(p,1.0);
        
        for(it_type=1; it_type<=ntypes; it_type++) {
        coeff = rhor_spline[type2rhor[it_type][it_type]][m];
        rho[i] += ( ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6] )*xi[j][it_type-1];
        if (newton_pair || j < nlocal) {
          rho[j] += ( ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6] )*xi[i][it_type-1];
        }
        }//end of it_type loop        
      }
    }//end of jj loop
  }//end of ii loop
  
  // communicate and sum densities
  
  if (newton_pair){flag=1; comm->reverse_comm_pair(this);}

  // phase average of rho
  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    //itype = type[i];
    jlist = firstneigh[i];
    jnum = numneigh[i];
    
    inv_imass=0.0;
    for(itype=1; itype<=ntypes; itype++) { inv_imass += xi[i][itype-1]/mass[itype]; }

    sigma_i = kconv*sqrt(temp[i]*inv_imass);

    for (jj = 0; jj < jnum; jj++) { //start neighbor loop
      j = jlist[jj];
      j &= NEIGHMASK;
      //jtype = type[j];
      
      inv_jmass=0.0;
      for(jtype=1; jtype<=ntypes; jtype++) { inv_jmass += xi[j][jtype-1]/mass[jtype]; }

      sigma_j = kconv*sqrt(temp[j]*inv_jmass);

      //Quadrature loop must start here
      for(i_quad =0; i_quad< n_quad2; i_quad++){   

      delx = xtmp - x[j][0] + QP2[i_quad][0]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][3]*sigma_j/frequency[j];

      dely = ytmp - x[j][1] + QP2[i_quad][1]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][4]*sigma_j/frequency[j];

      delz = ztmp - x[j][2] + QP2[i_quad][2]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][5]*sigma_j/frequency[j];

      rsq = delx*delx + dely*dely + delz*delz;

      if (rsq < cutforcesq) {        
        p = sqrt(rsq)*rdr + 1.0;
        m = static_cast<int> (p);
        m = MIN(m,nr-1);
        p -= m;
        p = MIN(p,1.0);
        
        for(it_type=1; it_type<=ntypes; it_type++) {        
        coeff = rhor_spline[type2rhor[it_type][it_type]][m];
        rho_mxe[i] += xi[j][it_type-1]*QW2[i_quad]*(((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6]);
        if (newton_pair || j < nlocal) {
          rho_mxe[j] += xi[i][it_type-1]*QW2[i_quad]*(((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6]);
        } //End newton pair
        }// end of it_type loop        
      } //End if (rqs < cut...)
     } //End quadrature points
    } //End neighbor loop
  } //End loop my atoms

  // communicate and sum densities

  if (newton_pair){flag=2; comm->reverse_comm_pair(this);}

  // fp = derivative of embedding energy at each atom
  // phi = embedding energy at each atom
  // if rho > rhomax (e.g. due to close approach of two atoms),
  //   will exceed table, so add linear term to conserve energy

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    //itype=type[i];
    p = rho[i]*rdrho + 1.0;
    m = static_cast<int> (p);
    m = MAX(1,MIN(m,nrho-1));
    p -= m;
    p = MIN(p,1.0);
    
    for(itype=1; itype<=ntypes; itype++) {
        
    coeff = frho_spline[type2frho[itype]][m];
    fp[i+nmax*(itype-1)] = (coeff[0]*p + coeff[1])*p + coeff[2];
    
    phi = ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6] + fp[i+nmax*(itype-1)]*(rho_mxe[i]-rho[i]); // <F(rho)>_0 = F(rho) + Fp(rho)*( <rho> - rho )
    if (rho[i] > rhomax) phi += fp[i+nmax*(itype-1)] * (rho[i]-rhomax);
    phi *= scale[itype][itype];
    
    if (eflag) {    
      if (eflag_global) eng_vdwl+= xi[i][itype-1]*phi;
      if (eflag_atom) eatom[i]  += xi[i][itype-1]*phi;
    }  
    
    // derivative wrt x 
    //fxi[i][itype-1] += ( 1.0+log(xi[i][itype-1]) )*(boltz*temp[i]); // included in fix_mass_transport_atom.cpp file
    fxi[i][itype-1] += phi;   
    
    }//end of itype loop
  }//end of ii loop

  // communicate derivative of embedding function

  comm->forward_comm_pair(this);

  // compute forces on each atom
  // loop over neighbors of my atoms

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    //itype = type[i];

    inv_imass=0.0;
    for(itype=1; itype<=ntypes; itype++) { inv_imass += xi[i][itype-1]/mass[itype]; }  
    
    sigma_i = kconv*sqrt(temp[i]*inv_imass);
    itemp_i  = 1.0/temp[i];

    jlist = firstneigh[i];
    jnum = numneigh[i];

    for (jj = 0; jj < jnum; jj++) {
      j = jlist[jj];
      j &= NEIGHMASK;
      //jtype = type[j];
      
      inv_jmass=0.0;
      for(jtype=1; jtype<=ntypes; jtype++) { inv_jmass += xi[j][jtype-1]/mass[jtype]; }

      sigma_j = kconv*sqrt(temp[j]*inv_jmass);
      itemp_j  = 1.0/temp[j];

      //Quadrature loop must start here
      for(i_quad =0; i_quad< n_quad2; i_quad++){  

      delx = xtmp - x[j][0] + QP2[i_quad][0]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][3]*sigma_j/frequency[j];

      dely = ytmp - x[j][1] + QP2[i_quad][1]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][4]*sigma_j/frequency[j];

      delz = ztmp - x[j][2] + QP2[i_quad][2]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][5]*sigma_j/frequency[j];

      rsq = delx*delx + dely*dely + delz*delz;

      if (rsq < cutforcesq) {
        r = sqrt(rsq);
        p = r*rdr + 1.0;
        m = static_cast<int> (p);
        m = MIN(m,nr-1);
        p -= m;
        p = MIN(p,1.0);

        // rhoip = derivative of (density at atom j due to atom i)
        // rhojp = derivative of (density at atom i due to atom j)
        // phi = pair potential energy
        // phip = phi'
        // z2 = phi * r
        // z2p = (phi * r)' = (phi' r) + phi
        // psip needs both fp[i] and fp[j] terms since r_ij appears in two
        //   terms of embed eng: Fi(sum rho_ij) and Fj(sum rho_ji)
        //   hence embed' = Fi(sum rho_ij) rhojp + Fj(sum rho_ji) rhoip
        // scale factor can be applied by thermodynamic integration
        
        for(itype=1; itype<=ntypes; itype++) {
        for(jtype=1; jtype<=ntypes; jtype++) {

        coeff = rhor_spline[type2rhor[itype][jtype]][m];
        rhoi  = ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6];
        rhoip = (coeff[0]*p + coeff[1])*p + coeff[2];
        coeff = rhor_spline[type2rhor[jtype][itype]][m];
        rhoj  = ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6];
        rhojp = (coeff[0]*p + coeff[1])*p + coeff[2];
        coeff = z2r_spline[type2z2r[itype][jtype]][m];
        z2p = (coeff[0]*p + coeff[1])*p + coeff[2];
        z2 = ((coeff[3]*p + coeff[4])*p + coeff[5])*p + coeff[6];

        recip = 1.0/r;
        phi = z2*recip;
        phip = z2p*recip - phi*recip;
        psip = fp[i+nmax*(itype-1)]*rhojp + fp[j+nmax*(jtype-1)]*rhoip + phip;
        fpair = -scale[itype][jtype]*QW2[i_quad]*psip*recip*xi[i][itype-1]*xi[j][jtype-1];

        f[i][0] += delx*fpair;
        f[i][1] += dely*fpair;
        f[i][2] += delz*fpair;

	dxi = delx*QP2[i_quad][0]*sigma_i/frequency[i];
	dyi = dely*QP2[i_quad][1]*sigma_i/frequency[i];
	dzi = delz*QP2[i_quad][2]*sigma_i/frequency[i];

	dhi_dwi = fpair*(dxi+dyi+dzi);
	freq_force[i] += itemp_i*dhi_dwi;
	
        // derivative wrt x        
        fxi[i][itype-1] += xi[j][jtype-1]*scale[itype][jtype]*QW2[i_quad]*(phi+fp[j+nmax*(jtype-1)]*rhoi);

        if (newton_pair || j < nlocal) {
          f[j][0] -= delx*fpair;
          f[j][1] -= dely*fpair;
          f[j][2] -= delz*fpair;

	  dxj = -delx*QP2[i_quad][3]*sigma_j/frequency[j];
	  dyj = -dely*QP2[i_quad][4]*sigma_j/frequency[j];
	  dzj = -delz*QP2[i_quad][5]*sigma_j/frequency[j];

	  dhj_dwj = fpair*(dxj+dyj+dzj);
	  freq_force[j] += itemp_j*dhj_dwj;
        
          // derivative wrt x
          fxi[j][jtype-1] += xi[i][itype-1]*scale[itype][jtype]*QW2[i_quad]*(phi+fp[i+nmax*(itype-1)]*rhoj); 
        
        }        

	if (eflag) evdwl = scale[itype][jtype]*QW2[i_quad]*xi[i][itype-1]*xi[j][jtype-1]*phi;

        if (evflag) ev_tally(i,j,nlocal,newton_pair,
                             evdwl,0.0,fpair,delx,dely,delz);
        } //end of jtype loop
        }//end of itype loop
       } //End rcut
      } //End quad points
    } //End neighbors
  } //End all atoms

  if (vflag_fdotr) virial_fdotr_compute();
}

/* ----------------------------------------------------------------------
   allocate all arrays
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::allocate()
{
  allocated = 1;
  int n = atom->ntypes;

  memory->create(setflag,n+1,n+1,"pair:setflag");
  for (int i = 1; i <= n; i++)
    for (int j = i; j <= n; j++)
      setflag[i][j] = 0;

  memory->create(cutsq,n+1,n+1,"pair:cutsq");

  map = new int[n+1];
  for (int i = 1; i <= n; i++) map[i] = -1;

  type2frho = new int[n+1];
  memory->create(type2rhor,n+1,n+1,"pair:type2rhor");
  memory->create(type2z2r,n+1,n+1,"pair:type2z2r");
  memory->create(scale,n+1,n+1,"pair:scale");
}

/* ----------------------------------------------------------------------
   global settings
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::settings(int narg, char **arg)
{
  if (narg > 0) error->all(FLERR,"Illegal pair_style command");
}

/* ----------------------------------------------------------------------
   set coeffs for one or more type pairs
   read DYNAMO funcfl file
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::coeff(int narg, char **arg)
{
  if (!allocated) allocate();

  if (narg != 3) error->all(FLERR,"Incorrect args for pair coefficients");

  // parse pair of atom types

  int ilo,ihi,jlo,jhi;
  force->bounds(FLERR,arg[0],atom->ntypes,ilo,ihi);
  force->bounds(FLERR,arg[1],atom->ntypes,jlo,jhi);

  // read funcfl file if hasn't already been read
  // store filename in Funcfl data struct

  int ifuncfl;
  for (ifuncfl = 0; ifuncfl < nfuncfl; ifuncfl++)
    if (strcmp(arg[2],funcfl[ifuncfl].file) == 0) break;

  if (ifuncfl == nfuncfl) {
    nfuncfl++;
    funcfl = (Funcfl *)
      memory->srealloc(funcfl,nfuncfl*sizeof(Funcfl),"pair:funcfl");
    read_file(arg[2]);
    int n = strlen(arg[2]) + 1;
    funcfl[ifuncfl].file = new char[n];
    strcpy(funcfl[ifuncfl].file,arg[2]);
  }

  // set setflag and map only for i,i type pairs
  // set mass of atom type if i = j

  int count = 0;
  for (int i = ilo; i <= ihi; i++) {
    for (int j = MAX(jlo,i); j <= jhi; j++) {
      if (i == j) {
        setflag[i][i] = 1;
        map[i] = ifuncfl;
        atom->set_mass(FLERR,i,funcfl[ifuncfl].mass);
        count++;
      }
      scale[i][j] = 1.0;
    }
  }

  if (count == 0) error->all(FLERR,"Incorrect args for pair coefficients");
}

/* ----------------------------------------------------------------------
   init specific to this pair style
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::init_style()
{
  // convert read-in file(s) to arrays and spline them

  file2array();
  array2spline();

  neighbor->request(this,instance_me);
  
  //**mxe
  // Generate the quadrature points for phase average
  //for two body interactions  
  
  int i_quad, imax, jmax;
  dim = 6;
  n_quad2 = 12;
  
  for(imax=0; imax<n_quad2; imax++) {
    QW2[imax] = 0.0;
    for(jmax=0; jmax<dim; jmax++) QP2[imax][jmax] = 0.0;
  }
  
  for(imax=0; imax<dim; imax++){
    QP2[imax][imax]     = sqrt((double)dim*0.5);
    QP2[imax+dim][imax] =-sqrt((double)dim*0.5);
  }
  
  for(i_quad=0; i_quad<n_quad2; i_quad++) QW2[i_quad] = 0.5/(double)dim;
  //**mxe
  
}

/* ----------------------------------------------------------------------
   init for one type pair i,j and corresponding j,i
------------------------------------------------------------------------- */

double PairEAMMXEMT_BI::init_one(int i, int j)
{
  // single global cutoff = max of cut from all files read in
  // for funcfl could be multiple files
  // for setfl or fs, just one file

  if (setflag[i][j] == 0) scale[i][j] = 1.0;
  scale[j][i] = scale[i][j];

  if (funcfl) {
    cutmax = 0.0;
    for (int m = 0; m < nfuncfl; m++)
      cutmax = MAX(cutmax,funcfl[m].cut);
  } else if (setfl) cutmax = setfl->cut;
  else if (fs) cutmax = fs->cut;

  cutforcesq = cutmax*cutmax;

  return cutmax;
}

/* ----------------------------------------------------------------------
   read potential values from a DYNAMO single element funcfl file
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::read_file(char *filename)
{
  Funcfl *file = &funcfl[nfuncfl-1];

  int me = comm->me;
  FILE *fptr;
  char line[MAXLINE];

  if (me == 0) {
    fptr = force->open_potential(filename);
    if (fptr == NULL) {
      char str[128];
      sprintf(str,"Cannot open EAM potential file %s",filename);
      error->one(FLERR,str);
    }
  }

  int tmp,nwords;
  if (me == 0) {
    fgets(line,MAXLINE,fptr);
    fgets(line,MAXLINE,fptr);
    sscanf(line,"%d %lg",&tmp,&file->mass);
    fgets(line,MAXLINE,fptr);
    nwords = sscanf(line,"%d %lg %d %lg %lg",
           &file->nrho,&file->drho,&file->nr,&file->dr,&file->cut);
  }

  MPI_Bcast(&nwords,1,MPI_INT,0,world);
  MPI_Bcast(&file->mass,1,MPI_DOUBLE,0,world);
  MPI_Bcast(&file->nrho,1,MPI_INT,0,world);
  MPI_Bcast(&file->drho,1,MPI_DOUBLE,0,world);
  MPI_Bcast(&file->nr,1,MPI_INT,0,world);
  MPI_Bcast(&file->dr,1,MPI_DOUBLE,0,world);
  MPI_Bcast(&file->cut,1,MPI_DOUBLE,0,world);

  if ((nwords != 5) || (file->nrho <= 0) || (file->nr <= 0) || (file->dr <= 0.0))
    error->all(FLERR,"Invalid EAM potential file");

  memory->create(file->frho,(file->nrho+1),"pair:frho");
  memory->create(file->rhor,(file->nr+1),"pair:rhor");
  memory->create(file->zr,(file->nr+1),"pair:zr");

  if (me == 0) grab(fptr,file->nrho,&file->frho[1]);
  MPI_Bcast(&file->frho[1],file->nrho,MPI_DOUBLE,0,world);

  if (me == 0) grab(fptr,file->nr,&file->zr[1]);
  MPI_Bcast(&file->zr[1],file->nr,MPI_DOUBLE,0,world);

  if (me == 0) grab(fptr,file->nr,&file->rhor[1]);
  MPI_Bcast(&file->rhor[1],file->nr,MPI_DOUBLE,0,world);

  if (me == 0) fclose(fptr);
}

/* ----------------------------------------------------------------------
   convert read-in funcfl potential(s) to standard array format
   interpolate all file values to a single grid and cutoff
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::file2array()
{
  int i,j,k,m,n;
  int ntypes = atom->ntypes;
  double sixth = 1.0/6.0;

  // determine max function params from all active funcfl files
  // active means some element is pointing at it via map

  int active;
  double rmax;
  dr = drho = rmax = rhomax = 0.0;

  for (int i = 0; i < nfuncfl; i++) {
    active = 0;
    for (j = 1; j <= ntypes; j++)
      if (map[j] == i) active = 1;
    if (active == 0) continue;
    Funcfl *file = &funcfl[i];
    dr = MAX(dr,file->dr);
    drho = MAX(drho,file->drho);
    rmax = MAX(rmax,(file->nr-1) * file->dr);
    rhomax = MAX(rhomax,(file->nrho-1) * file->drho);
  }

  // set nr,nrho from cutoff and spacings
  // 0.5 is for round-off in divide

  nr = static_cast<int> (rmax/dr + 0.5);
  nrho = static_cast<int> (rhomax/drho + 0.5);

  // ------------------------------------------------------------------
  // setup frho arrays
  // ------------------------------------------------------------------

  // allocate frho arrays
  // nfrho = # of funcfl files + 1 for zero array

  nfrho = nfuncfl + 1;
  memory->destroy(frho);
  memory->create(frho,nfrho,nrho+1,"pair:frho");

  // interpolate each file's frho to a single grid and cutoff

  double r,p,cof1,cof2,cof3,cof4;

  n = 0;
  for (i = 0; i < nfuncfl; i++) {
    Funcfl *file = &funcfl[i];
    for (m = 1; m <= nrho; m++) {
      r = (m-1)*drho;
      p = r/file->drho + 1.0;
      k = static_cast<int> (p);
      k = MIN(k,file->nrho-2);
      k = MAX(k,2);
      p -= k;
      p = MIN(p,2.0);
      cof1 = -sixth*p*(p-1.0)*(p-2.0);
      cof2 = 0.5*(p*p-1.0)*(p-2.0);
      cof3 = -0.5*p*(p+1.0)*(p-2.0);
      cof4 = sixth*p*(p*p-1.0);
      frho[n][m] = cof1*file->frho[k-1] + cof2*file->frho[k] +
        cof3*file->frho[k+1] + cof4*file->frho[k+2];
    }
    n++;
  }

  // add extra frho of zeroes for non-EAM types to point to (pair hybrid)
  // this is necessary b/c fp is still computed for non-EAM atoms

  for (m = 1; m <= nrho; m++) frho[nfrho-1][m] = 0.0;

  // type2frho[i] = which frho array (0 to nfrho-1) each atom type maps to
  // if atom type doesn't point to file (non-EAM atom in pair hybrid)
  // then map it to last frho array of zeroes

  for (i = 1; i <= ntypes; i++)
    if (map[i] >= 0) type2frho[i] = map[i];
    else type2frho[i] = nfrho-1;

  // ------------------------------------------------------------------
  // setup rhor arrays
  // ------------------------------------------------------------------

  // allocate rhor arrays
  // nrhor = # of funcfl files

  nrhor = nfuncfl;
  memory->destroy(rhor);
  memory->create(rhor,nrhor,nr+1,"pair:rhor");

  // interpolate each file's rhor to a single grid and cutoff

  n = 0;
  for (i = 0; i < nfuncfl; i++) {
    Funcfl *file = &funcfl[i];
    for (m = 1; m <= nr; m++) {
      r = (m-1)*dr;
      p = r/file->dr + 1.0;
      k = static_cast<int> (p);
      k = MIN(k,file->nr-2);
      k = MAX(k,2);
      p -= k;
      p = MIN(p,2.0);
      cof1 = -sixth*p*(p-1.0)*(p-2.0);
      cof2 = 0.5*(p*p-1.0)*(p-2.0);
      cof3 = -0.5*p*(p+1.0)*(p-2.0);
      cof4 = sixth*p*(p*p-1.0);
      rhor[n][m] = cof1*file->rhor[k-1] + cof2*file->rhor[k] +
        cof3*file->rhor[k+1] + cof4*file->rhor[k+2];
    }
    n++;
  }

  // type2rhor[i][j] = which rhor array (0 to nrhor-1) each type pair maps to
  // for funcfl files, I,J mapping only depends on I
  // OK if map = -1 (non-EAM atom in pair hybrid) b/c type2rhor not used

  for (i = 1; i <= ntypes; i++)
    for (j = 1; j <= ntypes; j++)
      type2rhor[i][j] = map[i];

  // ------------------------------------------------------------------
  // setup z2r arrays
  // ------------------------------------------------------------------

  // allocate z2r arrays
  // nz2r = N*(N+1)/2 where N = # of funcfl files

  nz2r = nfuncfl*(nfuncfl+1)/2;
  memory->destroy(z2r);
  memory->create(z2r,nz2r,nr+1,"pair:z2r");

  // create a z2r array for each file against other files, only for I >= J
  // interpolate zri and zrj to a single grid and cutoff

  double zri,zrj;

  n = 0;
  for (i = 0; i < nfuncfl; i++) {
    Funcfl *ifile = &funcfl[i];
    for (j = 0; j <= i; j++) {
      Funcfl *jfile = &funcfl[j];

      for (m = 1; m <= nr; m++) {
        r = (m-1)*dr;

        p = r/ifile->dr + 1.0;
        k = static_cast<int> (p);
        k = MIN(k,ifile->nr-2);
        k = MAX(k,2);
        p -= k;
        p = MIN(p,2.0);
        cof1 = -sixth*p*(p-1.0)*(p-2.0);
        cof2 = 0.5*(p*p-1.0)*(p-2.0);
        cof3 = -0.5*p*(p+1.0)*(p-2.0);
        cof4 = sixth*p*(p*p-1.0);
        zri = cof1*ifile->zr[k-1] + cof2*ifile->zr[k] +
          cof3*ifile->zr[k+1] + cof4*ifile->zr[k+2];

        p = r/jfile->dr + 1.0;
        k = static_cast<int> (p);
        k = MIN(k,jfile->nr-2);
        k = MAX(k,2);
        p -= k;
        p = MIN(p,2.0);
        cof1 = -sixth*p*(p-1.0)*(p-2.0);
        cof2 = 0.5*(p*p-1.0)*(p-2.0);
        cof3 = -0.5*p*(p+1.0)*(p-2.0);
        cof4 = sixth*p*(p*p-1.0);
        zrj = cof1*jfile->zr[k-1] + cof2*jfile->zr[k] +
          cof3*jfile->zr[k+1] + cof4*jfile->zr[k+2];

        z2r[n][m] = 27.2*0.529 * zri*zrj;
      }
      n++;
    }
  }

  // type2z2r[i][j] = which z2r array (0 to nz2r-1) each type pair maps to
  // set of z2r arrays only fill lower triangular Nelement matrix
  // value = n = sum over rows of lower-triangular matrix until reach irow,icol
  // swap indices when irow < icol to stay lower triangular
  // if map = -1 (non-EAM atom in pair hybrid):
  //   type2z2r is not used by non-opt
  //   but set type2z2r to 0 since accessed by opt

  int irow,icol;
  for (i = 1; i <= ntypes; i++) {
    for (j = 1; j <= ntypes; j++) {
      irow = map[i];
      icol = map[j];
      if (irow == -1 || icol == -1) {
        type2z2r[i][j] = 0;
        continue;
      }
      if (irow < icol) {
        irow = map[j];
        icol = map[i];
      }
      n = 0;
      for (m = 0; m < irow; m++) n += m + 1;
      n += icol;
      type2z2r[i][j] = n;
    }
  }
}

/* ---------------------------------------------------------------------- */

void PairEAMMXEMT_BI::array2spline()
{
  rdr = 1.0/dr;
  rdrho = 1.0/drho;

  memory->destroy(frho_spline);
  memory->destroy(rhor_spline);
  memory->destroy(z2r_spline);

  memory->create(frho_spline,nfrho,nrho+1,7,"pair:frho");
  memory->create(rhor_spline,nrhor,nr+1,7,"pair:rhor");
  memory->create(z2r_spline,nz2r,nr+1,7,"pair:z2r");

  for (int i = 0; i < nfrho; i++)
    interpolate(nrho,drho,frho[i],frho_spline[i]);

  for (int i = 0; i < nrhor; i++)
    interpolate(nr,dr,rhor[i],rhor_spline[i]);

  for (int i = 0; i < nz2r; i++)
    interpolate(nr,dr,z2r[i],z2r_spline[i]);
}

/* ---------------------------------------------------------------------- */

void PairEAMMXEMT_BI::interpolate(int n, double delta, double *f, double **spline)
{
  for (int m = 1; m <= n; m++) spline[m][6] = f[m];

  spline[1][5] = spline[2][6] - spline[1][6];
  spline[2][5] = 0.5 * (spline[3][6]-spline[1][6]);
  spline[n-1][5] = 0.5 * (spline[n][6]-spline[n-2][6]);
  spline[n][5] = spline[n][6] - spline[n-1][6];

  for (int m = 3; m <= n-2; m++)
    spline[m][5] = ((spline[m-2][6]-spline[m+2][6]) +
                    8.0*(spline[m+1][6]-spline[m-1][6])) / 12.0;

  for (int m = 1; m <= n-1; m++) {
    spline[m][4] = 3.0*(spline[m+1][6]-spline[m][6]) -
      2.0*spline[m][5] - spline[m+1][5];
    spline[m][3] = spline[m][5] + spline[m+1][5] -
      2.0*(spline[m+1][6]-spline[m][6]);
  }

  spline[n][4] = 0.0;
  spline[n][3] = 0.0;

  for (int m = 1; m <= n; m++) {
    spline[m][2] = spline[m][5]/delta;
    spline[m][1] = 2.0*spline[m][4]/delta;
    spline[m][0] = 3.0*spline[m][3]/delta;
  }
}

/* ----------------------------------------------------------------------
   grab n values from file fp and put them in list
   values can be several to a line
   only called by proc 0
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::grab(FILE *fptr, int n, double *list)
{
  char *ptr;
  char line[MAXLINE];

  int i = 0;
  while (i < n) {
    fgets(line,MAXLINE,fptr);
    ptr = strtok(line," \t\n\r\f");
    list[i++] = atof(ptr);
    while ((ptr = strtok(NULL," \t\n\r\f"))) list[i++] = atof(ptr);
  }
}

/* ---------------------------------------------------------------------- */

double PairEAMMXEMT_BI::single(int i, int j, int itype, int jtype,
                       double rsq, double factor_coul, double factor_lj,
                       double &fforce)
{
    error->all(FLERR,"The single function for PairEAMMXEMT_BI is not yet implemented for mxe");
}

/* ---------------------------------------------------------------------- */

int PairEAMMXEMT_BI::pack_forward_comm(int n, int *list, double *buf,
                               int pbc_flag, int *pbc)
{
  int i,j,m, type, ntypes;

  ntypes = atom->ntypes;
  m = 0;
  for (i = 0; i < n; i++) {
    j = list[i];
    for(type=0;type<ntypes;type++)buf[m++] = fp[j+nmax*type];
  }
  
  return m;
}

/* ---------------------------------------------------------------------- */

void PairEAMMXEMT_BI::unpack_forward_comm(int n, int first, double *buf)
{
  int i,m,last,type,ntypes;

  ntypes = atom->ntypes;
  m = 0;
  last = first+n;
  for (i = first; i < last; i++) {
    for(type=0;type<ntypes;type++)fp[i+nmax*type] = buf[m++];
  }
  
}

/* ---------------------------------------------------------------------- */

int PairEAMMXEMT_BI::pack_reverse_comm(int n, int first, double *buf)
{
  int i,m,last;

  m = 0;
  last = first + n;
  if(flag==1){
    for (i = first; i < last; i++) buf[m++] = rho[i];
  }else if(flag==2){
    for (i = first; i < last; i++) buf[m++] = rho_mxe[i];
  }
  return m;
}

/* ---------------------------------------------------------------------- */

void PairEAMMXEMT_BI::unpack_reverse_comm(int n, int *list, double *buf)
{
  int i,j,m;

  m = 0;
  if(flag==1){
    for (i = 0; i < n; i++) {
        j = list[i];
        rho[j] += buf[m++];
    }
  }else if(flag==2){
    for (i = 0; i < n; i++) {
        j = list[i];
        rho_mxe[j] += buf[m++];
    }
  }
}

/* ----------------------------------------------------------------------
   memory usage of local atom-based arrays
------------------------------------------------------------------------- */

double PairEAMMXEMT_BI::memory_usage()
{
  double bytes = maxeatom * sizeof(double);
  bytes += maxvatom*6 * sizeof(double);
  bytes += 2 * nmax * sizeof(double);
  return bytes;
}

/* ----------------------------------------------------------------------
   swap fp array with one passed in by caller
------------------------------------------------------------------------- */

void PairEAMMXEMT_BI::swap_eam(double *fp_caller, double **fp_caller_hold)
{
  double *tmp = fp;
  fp = fp_caller;
  *fp_caller_hold = tmp;
}

/* ---------------------------------------------------------------------- */

void *PairEAMMXEMT_BI::extract(const char *str, int &dim)
{
  dim = 2;
  if (strcmp(str,"scale") == 0) return (void *) scale;
  return NULL;
}
