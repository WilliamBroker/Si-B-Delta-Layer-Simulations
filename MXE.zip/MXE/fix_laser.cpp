
/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <string.h>
#include <stdlib.h>
#include "fix_laser.h"
#include "atom.h"
#include "update.h"
#include "modify.h"
#include "domain.h"
#include "comm.h"
#include "region.h"
#include "respa.h"
#include "input.h"
#include "variable.h"
#include "memory.h"
#include "error.h"
#include "force.h"

using namespace LAMMPS_NS;
using namespace FixConst;

/* ---------------------------------------------------------------------- */

FixLaser::FixLaser(LAMMPS *lmp, int narg, char **arg) :
  Fix(lmp, narg, arg)
{
  
  // fix 1 all laser I0 1.0 R 0.1 Lp 50.0 t0 0.50 sigma0 0.1 x 0.0 0.0
  if (narg != 16) error->all(FLERR,"Illegal fix laser command");

  dynamic_group_allow = 1;
#if 0
	S(z,t) = I_0 (1-R)L_p^{-1} \exp[-z/L_p] \exp[-(t-t_0)^2/(2*\sigma_0^2)]
	This fix implements a heat flow in the atoms given by the following expression:
	$q_{i} = i_o \exp(-x_i/l_p)\exp(-(t-t_0)/(2*\sigma^2))$ [K $\cdot$ ps] 
	and the rate of change og the energy associated to each atom is $\dot{e}_i = k_B q_i$ 
	where $k_B$ is the Boltzmann constant. The amount of energy absorbed by the sample is 
	e_i(x_i) = \int_0^t \dot{e}_i dt = \int_0^t  i_o \exp(-x_i/l_p)\exp(-(t-t_0)/(2*\sigma^2)) dt.
#endif
  if (strcmp(arg[3],"I0") == 0) I0 = force->numeric(FLERR,arg[4]);
  if (strcmp(arg[5],"R" ) == 0)  R = force->numeric(FLERR,arg[6]);
  if (strcmp(arg[7],"Lp") == 0) Lp = force->numeric(FLERR,arg[8]);
  if (strcmp(arg[9],"t0") == 0) t0 = force->numeric(FLERR,arg[10]);
  if (strcmp(arg[11],"sigma0") == 0) sigma0 = force->numeric(FLERR,arg[12]);
  if (strcmp(arg[13],"x") && strcmp(arg[13],"y") && strcmp(arg[13],"z"))
    error->all(FLERR,"Illegal laser command");
  axis = arg[13][0];

  if (axis == 'x') {
    dim_flag = 0;
    c1 = force->numeric(FLERR,arg[14]);
    c2 = force->numeric(FLERR,arg[15]);
  } else if (axis == 'y') {
    dim_flag = 1;
    c1 = force->numeric(FLERR,arg[14]);
    c2 = force->numeric(FLERR,arg[15]);
  } else if (axis == 'z') {
    dim_flag = 2;
    c1 = force->numeric(FLERR,arg[14]);
    c2 = force->numeric(FLERR,arg[15]);
  }

  time  = 0.0;
  time0 = 0.0;
}

/* ---------------------------------------------------------------------- */

FixLaser::~FixLaser()
{

}

/* ---------------------------------------------------------------------- */

int FixLaser::setmask()
{
  int mask = 0;
  mask |= INITIAL_INTEGRATE;
  mask |= POST_FORCE;
  return mask;
}

/* ---------------------------------------------------------------------- */

void FixLaser::init()
{
    // Some checks
    
    if (force->pair == NULL)
        error->all(FLERR,"Fix optfreq requires a pair style be defined");
    
    int count = 0;
    for (int i = 0; i < modify->nfix; i++) {
      if (strcmp(modify->fix[i]->style,"optfreq") == 0) count++;
      if (count > 1 && comm->me == 0)
         error->warning(FLERR,"More than one fix optfreq");
    }
    time0 = update->dt*update->ntimestep;
}

/* ---------------------------------------------------------------------- */

void FixLaser::initial_integrate(int vflag)
{
  double **x = atom->x;
  double *mxe_temperature = atom->mxe_temperature;
  int *mask = atom->mask;
  int nlocal = atom->nlocal;
  double dt = 0.0;   
  double value;

  time = update->dt*update->ntimestep-time0;

  for (int i = 0; i < nlocal; i++) {
    if (mask[i] & groupbit) {

    //	$q_i(x,t) = I_0 (1-R) \exp[-(x_i-x_0)/L_p] \exp[-(t-t_0)^2/(2*\sigma_0^2)]$
    if(dim_flag == 0) mxe_temperature[i] += I0*exp(-(x[i][0]-c1)/Lp)*exp(-(time-t0)*(time-t0)/(2.0*sigma0*sigma0))*update->dt;
    if(dim_flag == 1) mxe_temperature[i] += I0*exp(-(x[i][1]-c1)/Lp)*exp(-(time-t0)*(time-t0)/(2.0*sigma0*sigma0))*update->dt;
    if(dim_flag == 2) mxe_temperature[i] += I0*exp(-(x[i][2]-c1)/Lp)*exp(-(time-t0)*(time-t0)/(2.0*sigma0*sigma0))*update->dt;

    }
  }
  
}

/* ----------------------------------------------------------------------
   memory usage of local atom-based array
------------------------------------------------------------------------- */

double FixLaser::memory_usage()
{
  double bytes = 0.0;
  return bytes;
}
