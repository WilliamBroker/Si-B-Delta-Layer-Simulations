
/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
   Contributing author: Aidan Thompson (SNL)
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "pair_lj_cubic_mxe.h"
#include "atom.h"
#include "comm.h"
#include "force.h"
#include "neighbor.h"
#include "neigh_list.h"
#include "memory.h"
#include "error.h"

using namespace LAMMPS_NS;
using namespace PairLJCubicMXEConstants;

/* ---------------------------------------------------------------------- */

PairLJCubicMXE::PairLJCubicMXE(LAMMPS *lmp) : Pair(lmp) {}

/* ---------------------------------------------------------------------- */

PairLJCubicMXE::~PairLJCubicMXE()
{
  if (allocated) {
    memory->destroy(setflag);
    memory->destroy(cutsq);

    memory->destroy(cut);
    memory->destroy(cut_inner);
    memory->destroy(cut_inner_sq);
    memory->destroy(epsilon);
    memory->destroy(sigma);
    memory->destroy(lj1);
    memory->destroy(lj2);
    memory->destroy(lj3);
    memory->destroy(lj4);
  }
}

/* ---------------------------------------------------------------------- */

void PairLJCubicMXE::compute(int eflag, int vflag)
{
  int i,j,ii,jj,inum,jnum,itype,jtype;
  double xtmp,ytmp,ztmp,delx,dely,delz,evdwl,fpair;
  double rsq,r2inv,r6inv,forcelj,factor_lj;
  double r,t,rmin;
  int *ilist,*jlist,*numneigh,**firstneigh;

  evdwl = 0.0;
  if (eflag || vflag) ev_setup(eflag,vflag);
  else evflag = vflag_fdotr = 0;

  double **x = atom->x;
  double **f = atom->f;
  int *type = atom->type;
  int nlocal = atom->nlocal;
  double *special_lj = force->special_lj;
  int newton_pair = force->newton_pair;

  inum = list->inum;
  ilist = list->ilist;
  numneigh = list->numneigh;
  firstneigh = list->firstneigh;
  
  //** mxe **//
  double *frequency = atom->frequency;
  double *temp = atom->mxe_temperature;
  double *freq_force = atom->freq_force;
  double *mass = atom->mass;
  
  // kconv = unit conversion to compute the standar deviation of the spectral cloud of atoms
  // sigma = sqrt(2*boltz*temp/mass)/frequency =sqrt(2*boltz*temp/mass/frequency^2)
  // [distance]^2 = ([energy]/[temp])*[temp]*[time]^2/[mass] = ([force]*[time]/[mass]) * ([time]*[distance]) = ftm2v * [distance] = [distance]^2
  // kconv = sqrt(2*boltz*ftm2v)
  // for metal units -> kconv = 1.289531236951867
  double boltz = force->boltz;
  double kconv = sqrt(2*boltz*force->ftm2v);
  double sigma_i = 0.0, sigma_j = 0.0;
  double itemp_i = 0.0, itemp_j = 0.0;
  
  double dxi, dyi, dzi, dhi_dwi;                                                
  double dxj, dyj, dzj, dhj_dwj;                                                

  int i_quad;
  //** mxe **//

  // loop over neighbors of my atoms

  for (ii = 0; ii < inum; ii++) {
    i = ilist[ii];
    xtmp = x[i][0];
    ytmp = x[i][1];
    ztmp = x[i][2];
    itype = type[i];
    jlist = firstneigh[i];
    jnum = numneigh[i];

    sigma_i = kconv*sqrt(temp[i]/mass[type[i]]);
    itemp_i  = 1.0/temp[i];

    for (jj = 0; jj < jnum; jj++) {
      j = jlist[jj];
      factor_lj = special_lj[sbmask(j)];
      j &= NEIGHMASK;

      sigma_j = kconv*sqrt(temp[j]/mass[type[j]]);
      itemp_j  = 1.0/temp[j];

      //Quadrature loop must start here
      for(i_quad =0; i_quad< n_quad2; i_quad++){      

      delx = xtmp - x[j][0] + QP2[i_quad][0]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][3]*sigma_j/frequency[j];

      dely = ytmp - x[j][1] + QP2[i_quad][1]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][4]*sigma_j/frequency[j];

      delz = ztmp - x[j][2] + QP2[i_quad][2]*sigma_i/frequency[i] 
		  	    - QP2[i_quad][5]*sigma_j/frequency[j];

      rsq = delx*delx + dely*dely + delz*delz;
      jtype = type[j];

      if (rsq < cutsq[itype][jtype]) {
        r2inv = 1.0/rsq;
        if (rsq <= cut_inner_sq[itype][jtype]) {
          r6inv = r2inv*r2inv*r2inv;
          forcelj = r6inv * (lj1[itype][jtype]*r6inv - lj2[itype][jtype]);
        } else {
          r = sqrt(rsq);
          rmin = sigma[itype][jtype]*RT6TWO;
          t = (r - cut_inner[itype][jtype])/rmin;
          forcelj = epsilon[itype][jtype]*(-DPHIDS + A3*t*t/2.0)*r/rmin;
        }
        fpair = QW2[i_quad]*factor_lj*forcelj*r2inv;

        f[i][0] += delx*fpair;
        f[i][1] += dely*fpair;
        f[i][2] += delz*fpair;
        
        dxi = delx*QP2[i_quad][0]*sigma_i/(frequency[i]);
        dyi = dely*QP2[i_quad][1]*sigma_i/(frequency[i]);
        dzi = delz*QP2[i_quad][2]*sigma_i/(frequency[i]);
        dhi_dwi = fpair*( dxi + dyi + dzi );
        
        freq_force[i] += itemp_i*dhi_dwi;
        
        if (newton_pair || j < nlocal) {
          f[j][0] -= delx*fpair;
          f[j][1] -= dely*fpair;
          f[j][2] -= delz*fpair;
          
          dxj = -delx*QP2[i_quad][3]*sigma_j/(frequency[j]);
          dyj = -dely*QP2[i_quad][4]*sigma_j/(frequency[j]);
          dzj = -delz*QP2[i_quad][5]*sigma_j/(frequency[j]);     
          dhj_dwj = fpair*( dxj + dyj + dzj );
          
          freq_force[j] += itemp_j*dhj_dwj; 
        }

        if (eflag) {
          if (rsq <= cut_inner_sq[itype][jtype])
            evdwl = r6inv * (lj3[itype][jtype]*r6inv - lj4[itype][jtype]);
          else
            evdwl = epsilon[itype][jtype]*
              (PHIS + DPHIDS*t - A3*t*t*t/6.0);
          evdwl *= QW2[i_quad]*factor_lj;

          if (evflag) ev_tally(i,j,nlocal,newton_pair,
                             evdwl,0.0,fpair,delx,dely,delz);
        }
       }//End quad points
      }
    }
  }

  if (vflag_fdotr) virial_fdotr_compute();
}

/* ----------------------------------------------------------------------
   allocate all arrays
------------------------------------------------------------------------- */

void PairLJCubicMXE::allocate()
{
  allocated = 1;
  int n = atom->ntypes;

  memory->create(setflag,n+1,n+1,"pair:setflag");
  for (int i = 1; i <= n; i++)
    for (int j = i; j <= n; j++)
      setflag[i][j] = 0;

  memory->create(cutsq,n+1,n+1,"pair:cutsq");

  memory->create(cut,n+1,n+1,"pair:cut");
  memory->create(cut_inner,n+1,n+1,"pair:cut_inner");
  memory->create(cut_inner_sq,n+1,n+1,"pair:cut_inner_sq");
  memory->create(epsilon,n+1,n+1,"pair:epsilon");
  memory->create(sigma,n+1,n+1,"pair:sigma");
  memory->create(lj1,n+1,n+1,"pair:lj1");
  memory->create(lj2,n+1,n+1,"pair:lj2");
  memory->create(lj3,n+1,n+1,"pair:lj3");
  memory->create(lj4,n+1,n+1,"pair:lj4");
}

/* ----------------------------------------------------------------------
   global settings
------------------------------------------------------------------------- */

void PairLJCubicMXE::settings(int narg, char **arg)
{
  if (narg != 0) error->all(FLERR,"Illegal pair_style command");

  // NOTE: lj/cubic has no global cutoff. instead the cutoff is
  // inferred from the lj parameters. so we must not reset cutoffs here.
}

/* ----------------------------------------------------------------------
   set coeffs for one or more type pairs
------------------------------------------------------------------------- */

void PairLJCubicMXE::coeff(int narg, char **arg)
{
  if (narg != 4)
    error->all(FLERR,"Incorrect args for pair coefficients");
  if (!allocated) allocate();

  int ilo,ihi,jlo,jhi;
  force->bounds(FLERR,arg[0],atom->ntypes,ilo,ihi);
  force->bounds(FLERR,arg[1],atom->ntypes,jlo,jhi);

  double epsilon_one = force->numeric(FLERR,arg[2]);
  double sigma_one = force->numeric(FLERR,arg[3]);
  double rmin = sigma_one*RT6TWO;

  int count = 0;
  for (int i = ilo; i <= ihi; i++) {
    for (int j = MAX(jlo,i); j <= jhi; j++) {
      epsilon[i][j] = epsilon_one;
      sigma[i][j] = sigma_one;
      cut_inner[i][j] = rmin*SS;
      cut[i][j] = rmin*SM;
      setflag[i][j] = 1;
      count++;
    }
  }

  if (count == 0) error->all(FLERR,"Incorrect args for pair coefficients");

  //**mxe**
  // Generate the quadrature points for phase average
  //for two body interactions 
 
  int i_quad, imax, jmax;
  dim = 6;
  n_quad2 = 12;
  
  for(imax=0; imax<n_quad2; imax++) { 
    QW2[imax] = 0.0;
    for(jmax=0; jmax<dim; jmax++) QP2[imax][jmax] = 0.0;
  }
  
  for(imax=0; imax<dim; imax++){
    QP2[imax][imax]     = sqrt((double)dim*0.5);
    QP2[imax+dim][imax] =-sqrt((double)dim*0.5);
  }

  for(i_quad=0; i_quad<n_quad2; i_quad++) QW2[i_quad] = 0.5/(double)dim;
  //**mxe** 

}

/* ----------------------------------------------------------------------
   init for one type pair i,j and corresponding j,i
------------------------------------------------------------------------- */

double PairLJCubicMXE::init_one(int i, int j)
{
  if (setflag[i][j] == 0) {
    epsilon[i][j] = mix_energy(epsilon[i][i],epsilon[j][j],
                               sigma[i][i],sigma[j][j]);
    sigma[i][j] = mix_distance(sigma[i][i],sigma[j][j]);
    cut_inner[i][j] = mix_distance(cut_inner[i][i],cut_inner[j][j]);
    cut[i][j] = mix_distance(cut[i][i],cut[j][j]);
  }

  cut_inner_sq[i][j] = cut_inner[i][j]*cut_inner[i][j];
  lj1[i][j] = 48.0 * epsilon[i][j] * pow(sigma[i][j],12.0);
  lj2[i][j] = 24.0 * epsilon[i][j] * pow(sigma[i][j],6.0);
  lj3[i][j] = 4.0 * epsilon[i][j] * pow(sigma[i][j],12.0);
  lj4[i][j] = 4.0 * epsilon[i][j] * pow(sigma[i][j],6.0);

  cut_inner[j][i] = cut_inner[i][j];
  cut_inner_sq[j][i] = cut_inner_sq[i][j];
  lj1[j][i] = lj1[i][j];
  lj2[j][i] = lj2[i][j];
  lj3[j][i] = lj3[i][j];
  lj4[j][i] = lj4[i][j];

  return cut[i][j];
}

/* ----------------------------------------------------------------------
  proc 0 writes to restart file
------------------------------------------------------------------------- */

void PairLJCubicMXE::write_restart(FILE *fp)
{
  write_restart_settings(fp);

  int i,j;
  for (i = 1; i <= atom->ntypes; i++)
    for (j = i; j <= atom->ntypes; j++) {
      fwrite(&setflag[i][j],sizeof(int),1,fp);
      if (setflag[i][j]) {
        fwrite(&epsilon[i][j],sizeof(double),1,fp);
        fwrite(&sigma[i][j],sizeof(double),1,fp);
        fwrite(&cut_inner[i][j],sizeof(double),1,fp);
        fwrite(&cut[i][j],sizeof(double),1,fp);
      }
    }
}

/* ----------------------------------------------------------------------
  proc 0 reads from restart file, bcasts
------------------------------------------------------------------------- */

void PairLJCubicMXE::read_restart(FILE *fp)
{
  read_restart_settings(fp);
  allocate();

  int i,j;
  int me = comm->me;
  for (i = 1; i <= atom->ntypes; i++)
    for (j = i; j <= atom->ntypes; j++) {
      if (me == 0) fread(&setflag[i][j],sizeof(int),1,fp);
      MPI_Bcast(&setflag[i][j],1,MPI_INT,0,world);
      if (setflag[i][j]) {
        if (me == 0) {
          fread(&epsilon[i][j],sizeof(double),1,fp);
          fread(&sigma[i][j],sizeof(double),1,fp);
          fread(&cut_inner[i][j],sizeof(double),1,fp);
          fread(&cut[i][j],sizeof(double),1,fp);
        }
        MPI_Bcast(&epsilon[i][j],1,MPI_DOUBLE,0,world);
        MPI_Bcast(&sigma[i][j],1,MPI_DOUBLE,0,world);
        MPI_Bcast(&cut_inner[i][j],1,MPI_DOUBLE,0,world);
        MPI_Bcast(&cut[i][j],1,MPI_DOUBLE,0,world);
      }
    }
}

/* ----------------------------------------------------------------------
  proc 0 writes to restart file
------------------------------------------------------------------------- */

void PairLJCubicMXE::write_restart_settings(FILE *fp)
{
  fwrite(&mix_flag,sizeof(int),1,fp);
}

/* ----------------------------------------------------------------------
  proc 0 reads from restart file, bcasts
------------------------------------------------------------------------- */

void PairLJCubicMXE::read_restart_settings(FILE *fp)
{
  int me = comm->me;
  if (me == 0) {
    fread(&mix_flag,sizeof(int),1,fp);
  }
  MPI_Bcast(&mix_flag,1,MPI_INT,0,world);
}

/* ---------------------------------------------------------------------- */

double PairLJCubicMXE::single(int i, int j, int itype, int jtype,
                             double rsq,
                             double factor_coul, double factor_lj,
                             double &fforce)
{
    error->all(FLERR,"The single function for PairLJCubicMXE is not yet implemented for mxe");
}
