/* -*- c++ -*- ----------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------

   MXE implementation: M. Ponga (mponga@mech.ubc.ca, UBC), J.P. Mendez (jmendezg@caltech.edu, CALTECH)
   Citing USER-MXE package:

------------------------------------------------------------------------- */

#ifdef FIX_CLASS

FixStyle(setchempotential,FixSetChemPotential)

#else

#ifndef LMP_FIX_SET_CHEM_POTENTIAL_H
#define LMP_FIX_SET_CHEM_POTENTIAL_H

#include "fix.h"

namespace LAMMPS_NS {

class FixSetChemPotential : public Fix {
 public:
  FixSetChemPotential(class LAMMPS *, int, char **);
  virtual ~FixSetChemPotential();
  int setmask();
  virtual void init();
  void setup(int);
  virtual void post_force(int vflag);
  double compute_vector(int);

  double memory_usage();

 protected:
  double xvalue,yvalue,zvalue;
  int varflag,iregion;
  char *xstr,*ystr,*zstr;
  char *idregion;
  int xvar,yvar,zvar,xstyle,ystyle,zstyle;
  double foriginal[3],foriginal_all[3];
  int force_flag;

  int maxatom;
  double **sforce;
};

}

#endif
#endif

